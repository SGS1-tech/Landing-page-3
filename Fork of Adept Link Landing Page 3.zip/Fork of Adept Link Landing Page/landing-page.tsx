import { useState } from 'react'
import { ChevronDown, ChevronUp, Globe, Brain, ShieldCheck, UserPlus, Search, ShoppingCart, Package, CreditCard, CheckCircle } from 'lucide-react'

export default function LandingPage() {
  const [activeAccordion, setActiveAccordion] = useState<number | null>(null)
  const [formData, setFormData] = useState({ name: '', email: '', company: '', businessType: '' })

  const handleAccordionClick = (index: number) => {
    setActiveAccordion(activeAccordion === index ? null : index)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Form submitted:', formData)
    // Here you would typically send the data to your backend
    alert('Thank you for your interest! We will be in touch soon.')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="container mx-auto px-6 py-24 md:px-12 lg:px-24">
          <div className="grid gap-12 md:grid-cols-2 items-center">
            <div>
              <h1 className="text-4xl font-bold mb-4 md:text-5xl lg:text-6xl">
                Bridging Canadian and Vietnamese Agri-Food Markets
              </h1>
              <p className="text-xl mb-8">
                Discover a new era of cross-border trade in agricultural and processed foods with a secure, AI-powered B2B platform.
              </p>
              <div className="space-x-4">
                <button className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold hover:bg-blue-50 transition duration-300">
                  Get Early Access
                </button>
                <button className="bg-transparent border-2 border-white px-6 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition duration-300">
                  Learn More
                </button>
              </div>
            </div>
            <div className="hidden md:block">
              <img src="/placeholder.svg?height=400&width=600" alt="Diverse agri-food products" className="rounded-lg shadow-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Adept Link</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <Globe className="w-12 h-12 text-blue-600 mb-4" />, title: 'Cross-Border Trade Access', description: 'Seamlessly connect with verified suppliers and buyers across regions.' },
              { icon: <Brain className="w-12 h-12 text-blue-600 mb-4" />, title: 'AI-Powered Insights', description: 'Optimize your supply chain with accurate demand forecasting and data-driven insights.' },
              { icon: <ShieldCheck className="w-12 h-12 text-blue-600 mb-4" />, title: 'Secure Transactions', description: 'Engage in worry-free trade with built-in secure payment solutions.' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                {item.icon}
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition duration-300">
              Explore Our Solution
            </button>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <UserPlus className="w-12 h-12 text-blue-600 mb-4" />, title: 'Register & Create Profile', description: 'Set up a customized profile to match your business needs.' },
              { icon: <Search className="w-12 h-12 text-blue-600 mb-4" />, title: 'Connect & Discover Products', description: 'Easily find trusted suppliers or buyers and start browsing product listings.' },
              { icon: <ShoppingCart className="w-12 h-12 text-blue-600 mb-4" />, title: 'Manage & Transact Securely', description: 'Streamline orders, inventory, and payments in one place.' },
            ].map((step, index) => (
              <div key={index} className="text-center bg-white p-6 rounded-lg shadow-md">
                {step.icon}
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Core Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <Package className="w-12 h-12 text-blue-600 mb-4" />, title: 'Product Listings', description: 'Showcase your products and reach a wider audience with ease.' },
              { icon: <ShoppingCart className="w-12 h-12 text-blue-600 mb-4" />, title: 'Order Management', description: 'Efficiently manage orders and inventory for a smooth supply chain experience.' },
              { icon: <CreditCard className="w-12 h-12 text-blue-600 mb-4" />, title: 'Secure Payment Processing', description: 'Trade confidently with integrated payment solutions.' },
            ].map((feature, index) => (
              <div key={index} className="text-center bg-gray-50 p-6 rounded-lg shadow-md">
                {feature.icon}
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition duration-300">
              Sign Up for Early Access
            </button>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Trusted by Industry Leaders</h2>
          <div className="flex justify-center space-x-8 mb-12">
            {['Logo1', 'Logo2', 'Logo3', 'Logo4'].map((logo, index) => (
              <div key={index} className="bg-white p-4 rounded-lg shadow-md">
                <img src={`/placeholder.svg?height=60&width=120&text=${logo}`} alt={`Partner ${index + 1}`} className="h-12" />
              </div>
            ))}
          </div>
          <blockquote className="text-center text-xl italic text-gray-600 mb-4">
            "Adept Link has streamlined our cross-border transactions and helped us forecast demand with precision."
          </blockquote>
          <p className="text-center font-semibold">- Canadian Agri-Business</p>
        </div>
      </section>

      {/* Call-to-Action Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-8">Join Now and Get Early Access</h2>
          <p className="text-center text-xl mb-12">Be among the first to access exclusive platform features and optimize your cross-border trade.</p>
          <form onSubmit={handleSubmit} className="max-w-lg mx-auto bg-white p-8 rounded-lg shadow-xl">
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700 font-bold mb-2">Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 font-bold mb-2">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div className="mb-4">
              <label htmlFor="company" className="block text-gray-700 font-bold mb-2">Company</label>
              <input
                type="text"
                id="company"
                name="company"
                value={formData.company}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div className="mb-6">
              <label htmlFor="businessType" className="block text-gray-700 font-bold mb-2">Type of Business</label>
              <select
                id="businessType"
                name="businessType"
                value={formData.businessType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select...</option>
                <option value="buyer">Buyer</option>
                <option value="supplier">Supplier</option>
              </select>
            </div>
            <button type="submit" className="w-full bg-blue-600 text-white px-4 py-3 rounded-md font-semibold hover:bg-blue-700 transition duration-300">
              Get Free Trial
            </button>
          </form>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto">
            {[
              { question: 'What is Adept Link?', answer: 'Adept Link is a secure, AI-powered B2B platform that connects Canadian and Vietnamese agri-food markets, facilitating cross-border trade in agricultural and processed foods.' },
              { question: 'How does the platform support secure transactions?', answer: 'Adept Link incorporates built-in secure payment solutions and verification processes to ensure all transactions are protected and worry-free for both buyers and suppliers.' },
              { question: 'What kind of AI insights does the platform provide?', answer: 'Our AI-powered system offers accurate demand forecasting, market trend analysis, and data-driven insights to help optimize your supply chain and business decisions.' },
              { question: 'How can I become a beta tester?', answer: 'To become a beta tester, sign up for early access using the form on our website. Beta testers will be among the first to access exclusive platform features and provide valuable feedback.' },
            ].map((faq, index) => (
              <div key={index} className="mb-4 border-b border-gray-200 pb-4">
                <button
                  className="flex justify-between items-center w-full text-left font-semibold text-lg"
                  onClick={() => handleAccordionClick(index)}
                >
                  {faq.question}
                  {activeAccordion === index ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
                </button>
                {activeAccordion === index && (
                  <p className="mt-2 text-gray-600">{faq.answer}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                {['Solutions', 'Buyers', 'Suppliers', 'Resources', 'Contact'].map((link, index) => (
                  <li key={index}><a href="#" className="hover:text-blue-400 transition duration-300">{link}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <p>Email: info@adeptlink.com</p>
              <p>Phone: +1 (123) 456-7890</p>
            </div>
            <div>
              <h3  className="text-lg font-semibold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                {['Facebook', 'Twitter', 'LinkedIn', 'Instagram'].map((social, index) => (
                  <a key={index} href="#" className="hover:text-blue-400 transition duration-300">{social}</a>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-blue-400 transition duration-300">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-blue-400 transition duration-300">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center">
            <p>&copy; 2023 Adept Link. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}